//
//  SettingsView.swift
//  Miniket
//
//  Created by Benjamin Cristobal Faundez Martinez on 11-08-25.
//
import SwiftUI

struct SettingsView: View {
    @AppStorage("isDarkMode") private var isDarkMode = false
    @AppStorage("useSystemTheme") private var useSystemTheme = true
    @AppStorage("locationEnabled") private var locationEnabled = false
    @AppStorage("selectedLanguage") private var selectedLanguage = "es"
    @AppStorage("selectedRegion") private var selectedRegion = "CL"
    @AppStorage("notifyBirthdays") private var notifyBirthdays = true
    @AppStorage("notifyVetEvents") private var notifyVetEvents = true
    @AppStorage("isVetMode") private var isVetMode = false

    let languages = [("Español", "es"), ("English", "en"), ("Português", "pt")]
    let regions = [("Chile", "CL"), ("México", "MX"), ("Argentina", "AR"), ("Brasil", "BR")]

    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("Apariencia")) {
                    Toggle("Usar tema del sistema", isOn: $useSystemTheme)
                    if !useSystemTheme {
                        Toggle("Modo Oscuro", isOn: $isDarkMode)
                    }
                }

                Section(header: Text("Idioma")) {
                    Picker("Idioma", selection: $selectedLanguage) {
                        ForEach(languages, id: \.1) { name, code in
                            Text(name).tag(code)
                        }
                    }
                }

                Section(header: Text("Región")) {
                    Picker("Región", selection: $selectedRegion) {
                        ForEach(regions, id: \.1) { name, code in
                            Text(name).tag(code)
                        }
                    }
                }

                Section(header: Text("Localización")) {
                    Toggle("Permitir acceso a ubicación", isOn: $locationEnabled)
                        .onChange(of: locationEnabled) { enabled in
                            if enabled {
                                LocationManager.shared.requestPermission()
                            }
                        }
                }

                Section(header: Text("Notificaciones")) {
                    Toggle("Cumpleaños de mascotas", isOn: $notifyBirthdays)
                    Toggle("Eventos veterinarios", isOn: $notifyVetEvents)
                }

                Section(header: Text("Modo profesional")) {
                    Toggle("Activar funciones para veterinarios", isOn: $isVetMode)
                    Text("Oculta funciones sensibles para usuarios comunes.")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }

                Section(header: Text("Acerca de")) {
                    Text("MiniKet v1.0")
                    Text("Desarrollada por Benjamín")
                }
            }
            .navigationTitle("Configuración")
        }
        .preferredColorScheme(useSystemTheme ? nil : (isDarkMode ? .dark : .light))
    }
}
