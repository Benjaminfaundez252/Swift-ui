import SwiftUI

// MARK: - Modelo Pet

struct Pet: Identifiable {
    let id: UUID
    let name: String
    let date: Date

    var ageDescription: String {
        let age = Calendar.current.dateComponents([.year], from: date, to: Date()).year ?? 0
        return "\(age) años"
    }
}

// MARK: - Modelo VetEvent

struct VetEvent: Identifiable {
    let id: UUID
    let title: String
    let date: Date
}

// MARK: - PetStore

class PetStore: ObservableObject {
    @Published var pets: [Pet] = [
        Pet(id: UUID(), name: "Luna", date: Calendar.current.date(byAdding: .year, value: -3, to: Date())!),
        Pet(id: UUID(), name: "Max", date: Calendar.current.date(byAdding: .year, value: -5, to: Date())!)
    ]
}

// MARK: - Vista: Fichas clínicas

struct VetRecordsView: View {
    @ObservedObject var store: PetStore

    var body: some View {
        NavigationView {
            List {
                ForEach(store.pets) { pet in
                    VStack(alignment: .leading) {
                        Text(pet.name)
                            .font(.headline)
                        Text("Edad: \(pet.ageDescription)")
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                    }
                }
            }
            .navigationTitle("Fichas clínicas")
        }
    }
}

// MARK: - Vista: Agenda veterinaria

struct VetScheduleView: View {
    @State private var events: [VetEvent] = []
    @State private var showingAddEvent = false

    var body: some View {
        NavigationView {
            List {
                ForEach(events) { event in
                    VStack(alignment: .leading) {
                        Text(event.title)
                            .font(.headline)
                        Text(event.date.formatted(date: .abbreviated, time: .shortened))
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                    }
                }
            }
            .navigationTitle("Agenda veterinaria")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("➕") {
                        showingAddEvent = true
                    }
                }
            }
            .sheet(isPresented: $showingAddEvent) {
                AddVetEventView(events: $events)
            }
        }
    }
}

// MARK: - Vista: Agregar evento

struct AddVetEventView: View {
    @Binding var events: [VetEvent]
    @State private var title = ""
    @State private var date = Date()
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationView {
            Form {
                TextField("Título del evento", text: $title)
                DatePicker("Fecha", selection: $date, displayedComponents: [.date, .hourAndMinute])

                Button("Guardar") {
                    let newEvent = VetEvent(id: UUID(), title: title, date: date)
                    events.append(newEvent)
                    dismiss()
                }
            }
            .navigationTitle("Nuevo evento")
        }
    }
}

// MARK: - Vista principal

struct ContentView: View {
    @StateObject private var store = PetStore()
    @State private var showRecords = false
    @State private var showSchedule = false

    var body: some View {
        VStack(alignment: .leading, spacing: 20) {
            Text("MiniKet")
                .font(.largeTitle)
                .bold()
                .padding(.top)

            Text("🐾 Mascotas registradas")
                .font(.title2)

            ForEach(store.pets) { pet in
                VStack(alignment: .leading) {
                    Text(pet.name)
                        .font(.headline)
                    Text("Edad: \(pet.ageDescription)")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                }
                .padding(.bottom, 5)
            }

            Divider()

            Text("🩺 Funciones veterinarias")
                .font(.title2)

            Button("Ver fichas clínicas") {
                showRecords = true
            }
            .padding(.vertical, 5)

            Button("Ver agenda de controles") {
                showSchedule = true
            }
            .padding(.vertical, 5)

            Spacer()
        }
        .padding()
        .sheet(isPresented: $showRecords) {
            VetRecordsView(store: store)
        }
        .sheet(isPresented: $showSchedule) {
            VetScheduleView()
        }
    }
}

// MARK: - App

@main
struct MiniKetApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
