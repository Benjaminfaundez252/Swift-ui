import Foundation

struct Pet: Identifiable, Codable {
    let id: UUID
    var name: String
    var date: Date
    var isLegendary: Bool
    var audioFilename: String?
    var imageFilename: String?

    var audioURL: URL? {
        guard let filename = audioFilename else { return nil }
        return FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first?
            .appendingPathComponent("MiniketPets")
            .appendingPathComponent(filename)
    }

    var imageURL: URL? {
        guard let filename = imageFilename else { return nil }
        return FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first?
            .appendingPathComponent("MiniketPets")
            .appendingPathComponent(filename)
    }

    var dateFormatted: String {
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        return formatter.string(from: date)
    }
}
