//
//  AddPetView.swift
//  Miniket
//
//  Created by Benjamin Cristobal Faundez Martinez on 11-08-25.
//
import SwiftUI

struct AddPetView: View {
    @Environment(\.dismiss) private var dismiss
    @ObservedObject var store: PetStore

    @State private var name: String = ""
    @State private var date: Date = Date()
    @State private var isLegendary: Bool = false
    @State private var audioURL: URL?
    @State private var image: UIImage?

    @State private var showingAudioPicker = false
    @State private var showingCamera = false

    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("Basic Info")) {
                    TextField("Name", text: $name)
                    DatePicker("Date", selection: $date, displayedComponents: .date)
                    Toggle("Legendary 🌈", isOn: $isLegendary)
                }

                Section(header: Text("Photo")) {
                    if let image = image {
                        Image(uiImage: image)
                            .resizable()
                            .scaledToFit()
                            .frame(height: 150)
                    } else {
                        Text("No photo selected")
                            .foregroundColor(.secondary)
                    }

                    Button("Take Photo") {
                        showingCamera = true
                    }
                }

                Section(header: Text("Audio Memory")) {
                    if let audioURL = audioURL {
                        Text(audioURL.lastPathComponent)
                            .foregroundColor(.green)
                    } else {
                        Text("No audio selected")
                            .foregroundColor(.secondary)
                    }

                    Button("Select Audio") {
                        showingAudioPicker = true
                    }
                }

                Section {
                    Button("Add Pet") {
                        addPet()
                    }
                    .disabled(name.trimmingCharacters(in: .whitespaces).isEmpty)
                }
            }
            .navigationTitle("New Companion")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") {
                        dismiss()
                    }
                }
            }
            .sheet(isPresented: $showingAudioPicker) {
                DocumentPicker(audioURL: $audioURL)
            }
            .sheet(isPresented: $showingCamera) {
                ImagePicker(image: $image)
            }
        }
    }

    private func addPet() {
        let id = UUID()
        var audioFilename: String? = nil
        var imageFilename: String? = nil

        let folder = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
            .appendingPathComponent("MiniketPets")

        try? FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)

        if let audioURL = audioURL {
            let dest = folder.appendingPathComponent("\(id.uuidString).m4a")
            try? FileManager.default.copyItem(at: audioURL, to: dest)
            audioFilename = dest.lastPathComponent
        }

        if let image = image {
            let dest = folder.appendingPathComponent("\(id.uuidString).jpg")
            if let data = image.jpegData(compressionQuality: 0.8) {
                try? data.write(to: dest)
                imageFilename = dest.lastPathComponent
            }
        }

        let newPet = Pet(id: id, name: name, date: date, isLegendary: isLegendary, audioFilename: audioFilename, imageFilename: imageFilename)
        store.pets.insert(newPet, at: 0)
        store.savePets()
        dismiss()
    }
}
