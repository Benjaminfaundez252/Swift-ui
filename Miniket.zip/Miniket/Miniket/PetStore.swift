//
//  PetStore.swift
//  Miniket
//
//  Created by Benjamin Cristobal Faundez Martinez on 12-08-25.
//
import Foundation

class PetStore: ObservableObject {
    @Published var pets: [Pet] = []

    var legendaryPets: [Pet] {
        pets.filter { $0.isLegendary }
    }

    var recentPets: [Pet] {
        pets.filter { Calendar.current.isDateInToday($0.date) }
    }

    func loadPets() {
        let url = getPetsURL()
        guard let data = try? Data(contentsOf: url),
              let decoded = try? JSONDecoder().decode([Pet].self, from: data) else {
            pets = []
            return
        }
        pets = decoded
    }

    func savePets() {
        let url = getPetsURL()
        if let data = try? JSONEncoder().encode(pets) {
            try? data.write(to: url)
        }
    }

    private func getPetsURL() -> URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
            .appendingPathComponent("pets.json")
    }
}
