//
//  LocationManager.swift
//  Miniket
//
//  Created by Benjamin Cristobal Faundez Martinez on 12-08-25.
//
import Foundation
import CoreLocation

class LocationManager: NSObject, ObservableObject, CLLocationManagerDelegate {
    static let shared = LocationManager()

    private let manager = CLLocationManager()

    @Published var currentLocation: String?
    @Published var manualLocation: String? {
        didSet {
            saveManualLocation()
        }
    }

    override init() {
        super.init()
        manager.delegate = self
        manager.startUpdatingLocation()
        loadManualLocation()
    }

    func requestPermission() {
        manager.requestWhenInUseAuthorization()
    }

    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard manualLocation == nil, let loc = locations.last else { return }

        let geocoder = CLGeocoder()
        geocoder.reverseGeocodeLocation(loc) { placemarks, error in
            if let place = placemarks?.first {
                let locationString = [place.locality, place.country].compactMap { $0 }.joined(separator: ", ")
                DispatchQueue.main.async {
                    self.currentLocation = locationString
                }
            }
        }
    }

    var effectiveLocation: String? {
        manualLocation ?? currentLocation
    }

    private func saveManualLocation() {
        UserDefaults.standard.set(manualLocation, forKey: "manualLocation")
    }

    private func loadManualLocation() {
        manualLocation = UserDefaults.standard.string(forKey: "manualLocation")
    }
}
