//
//  PetRow.swift
//  Miniket
//
//  Created by Benjamin Cristobal Faundez Martinez on 12-08-25.
//
import SwiftUI

struct PetRow: View {
    let pet: Pet
    let playAudio: () -> Void

    var body: some View {
        HStack {
            VStack(alignment: .leading) {
                Text(pet.name)
                    .font(.headline)
                Text(pet.dateFormatted)
                    .font(.subheadline)
                    .foregroundColor(.gray)
            }

            Spacer()

            if pet.audioURL != nil {
                Button(action: playAudio) {
                    Image(systemName: "speaker.wave.2.fill")
                        .foregroundColor(.blue)
                }
            }

            if pet.isLegendary {
                Image(systemName: "star.fill")
                    .foregroundColor(.yellow)
            }
        }
        .padding(.vertical, 4)
    }
}
