//
//  ClinicalRecordView.swift
//  Miniket
//
//  Created by Benjamin Cristobal Faundez Martinez on 12-08-25.
//
import SwiftUI

struct ClinicalRecordView: View {
    let pet: Pet
    @State private var diagnosis: String = ""
    @State private var treatment: String = ""

    var body: some View {
        Form {
            Section(header: Text("Mascota")) {
                Text(pet.name)
                Text("Fecha de nacimiento: \(pet.date.formatted(date: .abbreviated, time: .omitted))")
            }

            Section(header: Text("Diagnóstico")) {
                TextField("Escribe el diagnóstico", text: $diagnosis)
            }

            Section(header: Text("Tratamiento")) {
                TextField("Escribe el tratamiento", text: $treatment)
            }

            Section {
                Button("Guardar") {
                    // Aquí podrías guardar en Core Data o archivo
                }
            }
        }
        .navigationTitle("Ficha de \(pet.name)")
    }
}
