//
//  SplashScreenView.swift
//  Miniket
//
//  Created by Benjamin Cristobal Faundez Martinez on 11-08-25.
//

import SwiftUI

struct SplashScreenView: View {
    var body: some View {
        ZStack {
            Color.white.edgesIgnoringSafeArea(.all)
            VStack {
                Image(systemName: "pawprint.fill")
                    .resizable()
                    .frame(width: 120, height: 120)
                    .foregroundColor(.orange)
                Text("MiniKet")
                    .font(.largeTitle)
                    .bold()
                    .foregroundColor(.orange)
                Text("Tu Pokédex de Mascotas")
                    .font(.headline)
                    .foregroundColor(.gray)
            }
        }
    }
}
