//
//  MainView.swift
//  Miniket
//
//  Created by Benjamin Cristobal Faundez Martinez on 11-08-25.
//
import SwiftUI

struct MainView: View {
    var body: some View {
        TabView {
            ContentView()
                .tabItem {
                    Label("Mascotas", systemImage: "pawprint.fill")
                }
            
            SettingsView()
                .tabItem {
                    Label("Configuración", systemImage: "gearshape.fill")
                }
        }
    }
}
